
import './App.css';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Book from './pages/Book';
import SaveBook from './pages/SaveBook';
import Login from './components/Login';
import Signup from './components/Signup';
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
function App() {
  return (
    <Router >
      <Navbar/>
      <Routes>
      <Route path="/" element={<Login/>}/>
          <Route path="/signup" element={<Signup/>}/>
        <Route exact path ="/home" element={<Home/>}/>
        <Route  path ="/books" element={<Book/>}/>
        <Route  path ="/saveBooks" element={<SaveBook/>}/>
      </Routes>
      <Footer/>
    </Router>

  );
}

export default App;
