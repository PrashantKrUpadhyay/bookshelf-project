import React from 'react';

const Footer = () => {
  return (
    <div className=" Footer d-flex bg-dark">
     <h5> Developed By Prashant</h5>
    </div>
  );
}

export default Footer;

