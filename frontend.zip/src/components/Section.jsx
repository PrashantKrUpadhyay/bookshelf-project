import React from 'react';

const Section = ({data}) => {
   
  return (
   
    
    <div className="section_class d-flex flex-wrap ">
        {data && data.map((item, index) => (
            <div className="grid">
                <div> <img  className="img-fluid " src={item.image} alt="/" /> </div>
        <h6 style={{ fontSize:"15px"}} className="text-white my-1 px-2">{item.bookname.slice(0,20)}...</h6>
        <b style={{ fontSize:"30px",}} className="text-white px-2  ">Rs.{item.price}</b>
        <div className="section_button"> 
        <button className="btn btn-primary">Update</button>
        <button className="btn btn-danger" >Delete</button>
        </div>
        
        </div>
        ))}
       
    </div>
  );
}

export default Section;
