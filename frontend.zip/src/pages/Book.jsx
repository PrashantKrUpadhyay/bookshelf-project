import React, { useState,useEffect } from 'react';
import "./Book.css";
import axios from "axios";
import Section from '../components/Section';


const Book = () => {
    const[Data,setData] =useState();
    useEffect(()=>{
        const fetch = async () =>{
            await axios.get("http://localhost:1000/api/v1/getBooks").then((res)=>setData(res.data.books));
        };
        fetch();
    });
  return (
    <div className="bg-dark" style={{minHeight:"91.5vh"}}>
        <div className="content d-flex">
      <h3 className="heading3">
        Books Shelf
      </h3>
      
    </div>
    {Data ? 
     <Section data={Data}/>
     : 
    <div className="text-white">Loading...</div>}
    </div>
  );
}

export default Book;
