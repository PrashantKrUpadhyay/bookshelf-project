import React from 'react';
import {Link} from "react-router-dom";

import "./Home.css";

const Home = () => {
    // const pic= require('../images/boy-studying-book.jpg');
    
  return (
  
    
    <div className="Home-Page bg-dark text-white container-fluid d-flex justify-content-center align-items-center">
        <div className="row-container ">
            <div className="col-lg-6 d-flex justify-content-center align-items-start flex-column" style={{ height: "91.5vh"}}>
       <h2  style={{ fontSize: "90px"}}>Books And Little Sunshine </h2>
       <h3 style={{ fontSize: "50px"}}>Bookstore</h3>
       <p  className="mb-0"style={{color:"grey"}}> Here are some books...</p>
       <Link to ="/books" className="viewBook my-3" > View Books</Link>
        </div>
        {/* <div className="col-lg-6 d-flex justify-content-center align-items-center flex-column" style={{ height: "91.5vh"}}>
            <img className="img-fluid homeimg"
             src={pic} alt="image"/>
        </div> */}
        
        </div>

     
    </div>
  );
}

export default Home;
